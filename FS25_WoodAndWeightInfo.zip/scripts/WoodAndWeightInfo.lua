-- Wood and Weight Info v1.0.0

WoodAndWeightInfo = {}
WoodAndWeightInfo.UPDATE_MS  = 100
WoodAndWeightInfo.MOD_NAME   = g_currentModName or "FS25_WoodAndWeightInfo"
WoodAndWeightInfo.MOD_DIR    = g_currentModDirectory or ""

WoodAndWeightInfo._splitClassIds = {}
WoodAndWeightInfo._enabled       = true
WoodAndWeightInfo._lastVehicle   = nil
WoodAndWeightInfo._actionEventHooked = false
WoodAndWeightInfo._bgOverlay = nil

-- HUD reposition state
WoodAndWeightInfo._repositionMode   = false
WoodAndWeightInfo._posCustom        = false
WoodAndWeightInfo._savedX           = 0.8418
WoodAndWeightInfo._savedY           = 0.0346
WoodAndWeightInfo._mouseX           = 0
WoodAndWeightInfo._mouseY           = 0
WoodAndWeightInfo._lastRepositionMs = -100000

-- Camera-rotation lockout (inlined Click-to-Switch trick: prevent the
-- active-vehicle camera from spinning while the mouse cursor is shown)
WoodAndWeightInfo._camLockVehicle = nil
WoodAndWeightInfo._camLockBackup  = nil

-- Reference resolution for aspect-ratio correction (tuned at 5120x1440)
local WAWI_REF_AR    = 5120 / 1440
local WAWI_DEFAULT_X = 0.802     -- wood-box top-left corner (LED HUD anchor)
local WAWI_DEFAULT_Y = 0.955

-- ─────────────────────────────────────────────
-- Unit helpers
-- ─────────────────────────────────────────────
local LB_PER_KG = 2.2046226218
local KG_PER_SHORT_TON = 907.18474

local function wawi_useImperial()
    -- Returns true if the game is set to miles (imperial weight/distance).
    if g_gameSettings ~= nil and GameSettings ~= nil and GameSettings.SETTING ~= nil then
        if GameSettings.SETTING.USE_MILES ~= nil then
            local ok, v = pcall(function() return g_gameSettings:getValue(GameSettings.SETTING.USE_MILES) end)
            if ok and type(v) == "boolean" then return v end
        end
    end
    if g_i18n ~= nil then
        if type(g_i18n.useMiles) == "boolean" then return g_i18n.useMiles end
        if g_i18n.hasImperialUnits ~= nil then
            local ok, v = pcall(function() return g_i18n:hasImperialUnits() end)
            if ok and type(v) == "boolean" then return v end
        end
    end
    return false
end

local function wawi_formatWeight(kg, useImperial)
    if useImperial then
        return string.format("%.0f lbs", (kg or 0) * LB_PER_KG)
    end
    return string.format("%.0f kg", kg or 0)
end

local function wawi_formatHeavy(kg, useImperial)
    if useImperial then
        return string.format("%.2f t", (kg or 0) / KG_PER_SHORT_TON)
    end
    return string.format("%.2f t", (kg or 0) / 1000.0)
end

local function wawi_formatLiters(liters)
    if UnitsUtil ~= nil and UnitsUtil.formatVolume ~= nil then
        return UnitsUtil.formatVolume(liters or 0, 0)
    end
    return string.format("%.0f L", liters or 0)
end

-- ─────────────────────────────────────────────
-- Notification helper
-- ─────────────────────────────────────────────
local function wawi_showNotification(msg)
    if g_currentMission == nil then return end
    pcall(function()
        if g_currentMission.hud ~= nil and g_currentMission.hud.addSideNotification ~= nil then
            g_currentMission.hud:addSideNotification(FSBaseMission.INGAME_NOTIFICATION_INFO or 0, msg)
        end
    end)
end

-- ─────────────────────────────────────────────
-- Settings persistence
-- ─────────────────────────────────────────────
local function wawi_settingsPath()
    local base = getUserProfileAppPath ~= nil and getUserProfileAppPath() or ""
    return base .. "modSettings/FS25_WoodAndWeightInfo/settings.xml"
end

local function wawi_loadSettings()
    local path = wawi_settingsPath()
    if fileExists ~= nil and not fileExists(path) then return end
    local xmlId = loadXMLFile ~= nil and loadXMLFile("WAWISettings", path) or nil
    if xmlId == nil or xmlId == 0 then return end
    pcall(function()
        local px = getXMLFloat(xmlId, "settings.hud#posX")
        local py = getXMLFloat(xmlId, "settings.hud#posY")
        if px ~= nil and py ~= nil then
            WoodAndWeightInfo._savedX    = px
            WoodAndWeightInfo._savedY    = py
            WoodAndWeightInfo._posCustom = true
        end
        local sc = getXMLFloat(xmlId, "settings.hud#scale")
        if sc ~= nil and sc > 0 then WoodAndWeightInfo._hudScale = sc end
        local hz = getXMLBool(xmlId, "settings.hud#horizontal")
        if hz ~= nil then WoodAndWeightInfo._horizontal = hz end
    end)
    pcall(function() delete(xmlId) end)
end

local function wawi_saveSettings()
    local path = wawi_settingsPath()
    pcall(function()
        local dir = getUserProfileAppPath() .. "modSettings"
        createFolder(dir)
        createFolder(dir .. "/FS25_WoodAndWeightInfo")
    end)
    local xmlId = createXMLFile ~= nil and createXMLFile("WAWISettings", path, "settings") or nil
    if xmlId == nil or xmlId == 0 then return end
    pcall(function()
        setXMLFloat(xmlId, "settings.hud#posX", WoodAndWeightInfo._savedX)
        setXMLFloat(xmlId, "settings.hud#posY", WoodAndWeightInfo._savedY)
        setXMLFloat(xmlId, "settings.hud#scale", WoodAndWeightInfo._hudScale or 0.533)
        setXMLBool(xmlId, "settings.hud#horizontal", WoodAndWeightInfo._horizontal == true)
        saveXMLFile(xmlId)
    end)
    pcall(function() delete(xmlId) end)
end

-- ─────────────────────────────────────────────
-- HUD position with aspect-ratio correction
-- ─────────────────────────────────────────────
local function wawi_getDrawPos()
    if WoodAndWeightInfo._posCustom then
        return WoodAndWeightInfo._savedX, WoodAndWeightInfo._savedY
    end
    return WAWI_DEFAULT_X, WAWI_DEFAULT_Y
end

-- ─────────────────────────────────────────────
-- Physics helpers
-- ─────────────────────────────────────────────
local function wawi_getMassKg(nodeId)
    if type(nodeId) ~= "number" or nodeId == 0 then return 0 end
    if entityExists ~= nil and not entityExists(nodeId) then return 0 end
    if getMass == nil then return 0 end
    local ok, t = pcall(getMass, nodeId)
    if not ok or t == nil or t <= 0 then return 0 end
    return t * 1000.0
end

local function wawi_getVolumeLiters(splitShapeId)
    if type(splitShapeId) ~= "number" or splitShapeId == 0 then return 0 end
    if entityExists ~= nil and not entityExists(splitShapeId) then return 0 end
    if getVolume == nil then return 0 end
    local ok, v = pcall(getVolume, splitShapeId)
    if not ok or v == nil or v <= 0 then return 0 end
    return v * 1000.0
end

local function wawi_getVehiclePhysicsMassKg(v)
    if v == nil then return 0 end
    local kg = 0
    if v.components ~= nil then
        for _, c in ipairs(v.components) do
            if c ~= nil and c.node ~= nil then
                kg = kg + wawi_getMassKg(c.node)
            end
        end
        if kg > 0 then return kg end
    end
    if v.rootNode ~= nil then return wawi_getMassKg(v.rootNode) end
    return 0
end

-- Given a node id that was joint-belted to a trailer, try to find the
-- Vehicle object it belongs to (by rootNode or any components[i].node).
-- Used to recover the vehicle's FULL physics mass for strapped vehicles,
-- since getMass(singleNode) on a multi-component vehicle only returns
-- that one component's mass (e.g., tractor chassis alone without wheels
-- / cab / engine block).
--   Returns Vehicle object on match, or nil if the node belongs to a
--   plain rigid body (pallet / crate) that should use getMass directly.
local function wawi_findVehicleByNode(nodeId)
    if type(nodeId) ~= "number" or nodeId == 0 then return nil end
    if g_currentMission == nil then return nil end
    local vehicles = g_currentMission.vehicles
    if type(vehicles) ~= "table" then return nil end
    for _, v in pairs(vehicles) do
        if type(v) == "table" then
            if v.rootNode == nodeId then return v end
            if type(v.components) == "table" then
                for _, c in ipairs(v.components) do
                    if c ~= nil and c.node == nodeId then return v end
                end
            end
        end
    end
    return nil
end

-- Resolve the mass of a strapped non-wood node. Preferred source is the
-- joint record's `object` field (confirmed via probe on 2026-04-19 to
-- be a direct reference to the strapped Vehicle / rigid body wrapper).
-- Falling back in order: g_currentMission.vehicles walk by nodeId,
-- then raw getMass(nodeId) for plain rigid bodies (pallets / crates).
-- Why this matters: getMass(singleNode) on a multi-component vehicle
-- returns only that one rigid body's share of the mass (e.g., the
-- Valtra S 286's strapped rootNode reports 5700 kg, not its full
-- 10,374 kg), because GIANTS distributes vehicle mass across several
-- component bodies.
--   Returns: (kg, resolvedVia) where resolvedVia is "jointRec.object"
--   / "vehicle-lookup" / "node".
local function wawi_resolveStrappedObjectMassKg(nodeId, jointRec)
    -- Path 1: jointRec.object is (per probe) the strapped Vehicle.
    if type(jointRec) == "table" and type(jointRec.object) == "table" then
        local obj = jointRec.object
        if type(obj.components) == "table" or type(obj.rootNode) == "number" then
            local vm = wawi_getVehiclePhysicsMassKg(obj)
            if vm > 0 then return vm, "jointRec.object" end
        end
    end
    -- Path 2: scan g_currentMission.vehicles for a matching rootNode /
    -- component node. Covers cases where jointRec.object isn't a Vehicle.
    local vehicle = wawi_findVehicleByNode(nodeId)
    if vehicle ~= nil then
        local vm = wawi_getVehiclePhysicsMassKg(vehicle)
        if vm > 0 then return vm, "vehicle-lookup" end
    end
    -- Path 3: plain rigid body (pallet / crate / unknown).
    return wawi_getMassKg(nodeId), "node"
end

-- ─────────────────────────────────────────────
-- Fill mass
-- ─────────────────────────────────────────────
-- Check if a fill unit is consumed by the vehicle's engine (motor consumers).
-- Returns true only for fill units that feed the engine (e.g. the tractor's
-- own diesel tank), NOT for cargo/external fuel tanks. This is the universal
-- fuel test: any fill unit registered as a motor consumer IS fuel by
-- definition — including modded fuel types (hydrogen, biodiesel, etc.) we
-- can't anticipate by name.
local function wawi_isConsumerFillUnit(v, fillUnitIndex)
    if v == nil or v.spec_motorized == nil then return false end
    local consumers = v.spec_motorized.consumers
    if consumers == nil then return false end
    for _, consumer in ipairs(consumers) do
        if consumer.fillUnitIndex == fillUnitIndex then return true end
    end
    return false
end

local function wawi_getFillMassKg(v, excludeFuel)
    if v == nil or v.getFillUnits == nil or v.getFillUnitFillLevel == nil then return 0 end
    if g_fillTypeManager == nil then return 0 end
    local totalKg = 0
    local fillUnits = v:getFillUnits()
    if fillUnits == nil then return 0 end
    for i, _ in ipairs(fillUnits) do
        local liters = v:getFillUnitFillLevel(i) or 0
        if liters > 0 then
            local ftIdx = v:getFillUnitFillType(i)
            if ftIdx ~= nil and FillType ~= nil and ftIdx ~= FillType.UNKNOWN then
                if excludeFuel and wawi_isConsumerFillUnit(v, i) then
                    -- skip engine-consumed fuel (tractor's own tank)
                else
                    local ft = g_fillTypeManager:getFillTypeByIndex(ftIdx)
                    local mpl = 0
                    if ft ~= nil then mpl = ft.massPerLiter or ft.density or 0 end
                    if mpl > 0 then totalKg = totalKg + (liters * mpl * 1000) end
                end
            end
        end
    end
    return totalKg
end

local function wawi_hasFillVolume(v)
    if v == nil or v.getFillUnits == nil then return false end
    local fu = v:getFillUnits()
    return fu ~= nil and #fu > 0
end

-- Total liters held in CARGO fill units (non-consumer) on a vehicle.
-- Consumer fill units (diesel/methane/electric/DEF/AIR) are always
-- excluded from Load by design, so they also don't count toward the
-- "is this vehicle actually empty of cargo?" test used to clamp
-- phantom-Load physics residuals. Examples of residuals this catches:
--   * Empty trailer: rawPhys 1600.36 vs empty 1600 -> ~0.36 kg noise
--   * Combine post-harvest: 12-17 kg of GIANTS threshing residue that
--     persists in rawPhysicsKg until the next full harvest cycle
-- If this returns 0, clamp vFillContribKg to 0.
local function wawi_getTotalCargoLiters(v)
    if v == nil or v.getFillUnits == nil then return 0 end
    local fu = v:getFillUnits()
    if fu == nil then return 0 end
    local total = 0
    for i, _ in ipairs(fu) do
        if not wawi_isConsumerFillUnit(v, i) then
            total = total + (v:getFillUnitFillLevel(i) or 0)
        end
    end
    return total
end

-- ─────────────────────────────────────────────
-- Zero-drift fill mass: empty-mass API + fill-type physics density
-- ─────────────────────────────────────────────
-- Returns the vehicle's configured empty mass in KILOGRAMS, or nil if
-- the API isn't available / returns nonsense. v:getDefaultMass() is a
-- universal Vehicle method (basegame + mods via shared Vehicle class)
-- and reports the value in TONS. Confirmed via probe on 2026-04-19:
-- combine 8.81 t, header 1.7 t, both stable across loaded/unloaded
-- states. Sanity-clamped to (0, 1000 tons).
local function wawi_getEmptyMassKg(v)
    if v == nil or type(v.getDefaultMass) ~= "function" then return nil end
    local ok, t = pcall(v.getDefaultMass, v)
    if not ok or type(t) ~= "number" then return nil end
    if t <= 0 or t > 1000 then return nil end
    return t * 1000.0
end

-- Physics density in kg/L, sourced from the fill-type manager's
-- massPerLiter record (tons/L * 1000). Returns 0 if unknown.
-- GIANTS fillVolume physics uses the same density record, so every
-- custom fill type registered in any map/mod is handled automatically.
local function wawi_getPhysicsDensityKgPerL(ftIdx)
    if ftIdx == nil or g_fillTypeManager == nil then return 0 end
    local ft = g_fillTypeManager:getFillTypeByIndex(ftIdx)
    if ft == nil then return 0 end
    return ((ft.massPerLiter or ft.density) or 0) * 1000.0
end

-- Sum of engine-consumed fuel mass (kg) across a vehicle's fill units,
-- using the fill-type manager's physics density (same record GIANTS'
-- fillVolume physics uses). Subtracted from the Load row so only
-- user-added fill counts. Relies entirely on isConsumerFillUnit — any
-- fill unit a motor is registered to consume IS fuel (basegame or
-- modded, by definition).
local function wawi_getConsumerFuelPhysicsKg(v)
    if v == nil or v.getFillUnits == nil then return 0 end
    local fu = v:getFillUnits()
    if fu == nil then return 0 end
    local total = 0
    for i, _ in ipairs(fu) do
        local liters = v:getFillUnitFillLevel(i) or 0
        if liters > 0 and wawi_isConsumerFillUnit(v, i) then
            local ftIdx = v.getFillUnitFillType and v:getFillUnitFillType(i) or nil
            if ftIdx ~= nil and FillType ~= nil and ftIdx ~= FillType.UNKNOWN then
                local d = wawi_getPhysicsDensityKgPerL(ftIdx)
                if d > 0 then total = total + liters * d end
            end
        end
    end
    return total
end

-- ─────────────────────────────────────────────
-- Vehicle chain helpers
-- ─────────────────────────────────────────────
local function wawi_getAttacherVehicle(v)
    if v == nil then return nil end
    if v.getAttacherVehicle ~= nil then
        local ok, res = pcall(function() return v:getAttacherVehicle() end)
        if ok and res ~= nil then return res end
    end
    if v.attacherVehicle ~= nil then return v.attacherVehicle end
    if v.spec_attachable ~= nil and v.spec_attachable.attacherVehicle ~= nil then
        return v.spec_attachable.attacherVehicle
    end
    return nil
end

local function wawi_getTopVehicle(start)
    local v = start
    local guard = 0
    while v ~= nil and guard < 24 do
        local parent = wawi_getAttacherVehicle(v)
        if parent == nil then break end
        v = parent
        guard = guard + 1
    end
    return v
end

local function wawi_iterateAttached(root, fn)
    if root == nil then return end
    fn(root)
    if root.getAttachedImplements == nil then return end
    local a = root:getAttachedImplements()
    if a == nil then return end
    for _, imp in ipairs(a) do
        if imp ~= nil and imp.object ~= nil then
            wawi_iterateAttached(imp.object, fn)
        end
    end
end

-- ─────────────────────────────────────────────
-- Active vehicle  (multiple strategies)
-- ─────────────────────────────────────────────
local function wawi_getActiveVehicle()
    if g_currentMission == nil then return nil end
    local m = g_currentMission

    if m.controlledVehicle ~= nil then return m.controlledVehicle end

    if m.getControlledVehicle ~= nil then
        local ok, v = pcall(function() return m:getControlledVehicle() end)
        if ok and v ~= nil then return v end
    end

    if m.player ~= nil then
        if m.player.getCurrentVehicle ~= nil then
            local ok, v = pcall(function() return m.player:getCurrentVehicle() end)
            if ok and v ~= nil then return v end
        end
        if m.player.getControlledVehicle ~= nil then
            local ok, v = pcall(function() return m.player:getControlledVehicle() end)
            if ok and v ~= nil then return v end
        end
    end

    if g_localPlayer ~= nil then
        if g_localPlayer.getCurrentVehicle ~= nil then
            local ok, v = pcall(function() return g_localPlayer:getCurrentVehicle() end)
            if ok and v ~= nil then return v end
        end
        if g_localPlayer.currentVehicle ~= nil then
            return g_localPlayer.currentVehicle
        end
    end

    return nil
end

-- ─────────────────────────────────────────────
-- Split-shape cache
-- ─────────────────────────────────────────────
local function wawi_buildSplitClassIdCache()
    WoodAndWeightInfo._splitClassIds = {}
    if ClassIds == nil then return end
    for k, v in pairs(ClassIds) do
        if type(k) == "string" and type(v) == "number" then
            local lk = string.lower(k)
            if string.find(lk, "splitshape", 1, true) ~= nil
            or string.find(lk, "split_shape", 1, true) ~= nil then
                WoodAndWeightInfo._splitClassIds[v] = true
            end
        end
    end
end

local function wawi_hasAnyClassId(nodeId, classSet)
    if getHasClassId == nil then return false end
    for classId, _ in pairs(classSet) do
        local ok, res = pcall(getHasClassId, nodeId, classId)
        if ok and res == true then return true end
    end
    return false
end

local function wawi_isSplitShapeId(id)
    if type(id) ~= "number" or id == 0 then return false end
    if entityExists ~= nil and not entityExists(id) then return false end
    if next(WoodAndWeightInfo._splitClassIds) == nil then return false end
    return wawi_hasAnyClassId(id, WoodAndWeightInfo._splitClassIds)
end

-- ─────────────────────────────────────────────
-- Strapped-object collection (wood + non-wood, one pass)
-- ─────────────────────────────────────────────
-- Returns: woodL, woodKg, woodPieces, nonWoodKg
--
-- Only counts items that are physically STRAPPED (actively joint-attached
-- via tension belts), not items merely sitting within the belt bounding box.
--   objectsToJoint        - keyed by node id (or object) for items with an
--                           active belt joint. Contains BOTH wood split
--                           shapes and other rigid bodies (pallets, vehicles).
--   strappedSplitShapes   - explicit wood lists populated when belts lock on.
--   strappedSplitShapeIds
--   strappedObjects /     - strapped non-wood items (pallets, machines,
--   mountedObjects          equipment, attachments, vehicles on deck).
local function wawi_getMountedTable(specTB)
    if specTB == nil then return nil end
    if specTB.strappedObjects ~= nil then return specTB.strappedObjects end
    if specTB.mountedObjects  ~= nil then return specTB.mountedObjects end
    local sys = specTB.tensionBeltSystem
    if sys ~= nil then
        if sys.strappedObjects    ~= nil then return sys.strappedObjects end
        if sys.mountedObjects     ~= nil then return sys.mountedObjects end
        if sys.getStrappedObjects ~= nil then
            local ok, res = pcall(function() return sys:getStrappedObjects() end)
            if ok then return res end
        end
        if sys.getMountedObjects  ~= nil then
            local ok, res = pcall(function() return sys:getMountedObjects() end)
            if ok then return res end
        end
    end
    return nil
end

-- Returns: woodL, woodKg, woodPieces, beltNonWoodKg, dmaNonWoodKg,
--          hasBeltObjects, hasDMAObjects
-- We split non-wood mass by SOURCE because the two paths have different
-- physics semantics and need different reconciliation in the main loop:
--   beltNonWoodKg — belt-strapped cargo (pallets, vehicles on a flatbed,
--                   autoload-trailer bales). Two flavors, distinguished
--                   by physics delta in the main loop:
--                     (a) Separate rigid body: getMass returns the full
--                         mass; trailer rawPhys = empty (no merge).
--                     (b) Merged into trailer rigid body (autoload bale
--                         trailers): getMass returns ~residual; trailer
--                         rawPhys = empty + bale mass. Main loop swaps
--                         to physics delta when (rawPhys-empty-fuel-wood)
--                         > 50 with hasBeltObjects.
--   dmaNonWoodKg  — dynamic-mount-attached cargo. Same two flavors as
--                   belts (spike = separate body, autoload-DMA = merged).
--                   Main loop also reclassifies via hasDMAObjects.
--   hasBeltObjects — true if any belt-mounted body was found. Triggers
--                    merged-cargo reconciliation for autoload trailers
--                    that route via tensionBelts.objectsToJoint.
--   hasDMAObjects — true if any DMA-mounted body was found. Triggers
--                   merged-cargo reconciliation for autoload trailers
--                   that route via dynamicMountAttacher.
local function wawi_collectStrappedFromBeltSpec(v)
    if v == nil then return 0, 0, 0, 0, 0, false, false end
    local specTB  = v.spec_tensionBelts
    local specDMA = v.spec_dynamicMountAttacher
    if specTB == nil and specDMA == nil then return 0, 0, 0, 0, 0, false, false end

    -- Two candidate sets so we can split non-wood mass by source.
    -- Belt candidates may be wood OR non-wood; DMA-only candidates are
    -- always non-wood (DMA isn't used for split-shape wood). We dedup
    -- by skipping DMA entries already in beltCandidates so a belt walk
    -- (with its more authoritative jointRec.objectMass) wins.
    local beltCandidates = {}
    local dmaCandidates  = {}
    -- By-node-id lookup of each joint record, so we can recover the
    -- per-piece original mass via record.objectMass (in tons). The
    -- game caches this at join-time so it can un-merge cleanly on
    -- belt release, which makes it the most authoritative per-shape
    -- mass source available (better than getMass — the shape's own
    -- physics mass drops to a ~10 kg residual after the merge).
    local jointByNodeId  = {}
    -- For DMA-only entries we still want the full Vehicle reference so
    -- multi-component pallets/vehicles report their FULL mass, not the
    -- single-node share that getMass returns.
    local objectByNodeId = {}

    if specTB ~= nil then
        -- Primary: objectsToJoint (actively joint-attached via belts).
        -- Keys may be node ids (number) or object tables.
        if type(specTB.objectsToJoint) == "table" then
            for k, val in pairs(specTB.objectsToJoint) do
                local nodeId = nil
                if type(k) == "number" then
                    nodeId = k
                elseif type(k) == "table" then
                    if     type(k.rootNode) == "number" then nodeId = k.rootNode
                    elseif type(k.nodeId)   == "number" then nodeId = k.nodeId
                    end
                end
                if type(nodeId) == "number" and nodeId ~= 0 then
                    beltCandidates[nodeId] = true
                    if type(val) == "table" then
                        jointByNodeId[nodeId] = val
                    end
                end
            end
        end

        -- Wood-specific strapped lists
        if type(specTB.strappedSplitShapes) == "table" then
            for _, val in pairs(specTB.strappedSplitShapes) do
                if type(val) == "number" then beltCandidates[val] = true end
            end
        end
        if type(specTB.strappedSplitShapeIds) == "table" then
            for _, val in pairs(specTB.strappedSplitShapeIds) do
                if type(val) == "number" then beltCandidates[val] = true end
            end
        end

        -- Non-wood strapped objects (pallets / vehicles / machines)
        local mountedTbl = wawi_getMountedTable(specTB)
        if mountedTbl ~= nil then
            for _, entry in pairs(mountedTbl) do
                local node = nil
                if type(entry) == "table" then
                    if     type(entry.rootNode) == "number"                                 then node = entry.rootNode
                    elseif type(entry.node)     == "number"                                 then node = entry.node
                    elseif entry.object ~= nil and type(entry.object.rootNode) == "number" then node = entry.object.rootNode
                    end
                elseif type(entry) == "number" then
                    node = entry
                end
                if type(node) == "number" and node ~= 0 then
                    beltCandidates[node] = true
                end
            end
        end
    end

    -- Dynamic-mount attacher: a separate attachment mechanism from
    -- tension belts. Used by:
    --   * Bale spikes (implementDynamicMountAttacher) holding bales
    --   * Autoload trailers with pallet mounts
    --   * Any vehicle's "dynamic mount" of a rigid-body cargo
    -- DMA-only candidates (skipped if already a belt candidate) live
    -- in dmaCandidates so the main loop can decide between getMass
    -- (separate body) and physics-delta (merged into trailer rigid body)
    -- per-vehicle.
    if specDMA ~= nil and type(specDMA.dynamicMountedObjects) == "table" then
        for key, val in pairs(specDMA.dynamicMountedObjects) do
            local obj, nodeId = nil, nil
            if type(key) == "table" then
                obj = key
            elseif type(val) == "table" and val.object ~= nil then
                obj = val.object
            end
            if type(obj) == "table" then
                if     type(obj.rootNode) == "number" then nodeId = obj.rootNode
                elseif type(obj.nodeId)   == "number" then nodeId = obj.nodeId
                end
            elseif type(key) == "number" then
                nodeId = key
            end
            if type(nodeId) == "number" and nodeId ~= 0 and not beltCandidates[nodeId] then
                dmaCandidates[nodeId] = true
                if obj ~= nil then objectByNodeId[nodeId] = obj end
            end
        end
    end

    local hasBeltObjects = next(beltCandidates) ~= nil
    local hasDMAObjects  = next(dmaCandidates)  ~= nil
    if not hasBeltObjects and not hasDMAObjects then
        return 0, 0, 0, 0, 0, false, false
    end

    local woodL, woodKg, woodPieces = 0, 0, 0
    local beltNonWoodKg = 0
    local dmaNonWoodKg  = 0

    -- Resolved strapped Vehicle objects (e.g. a tractor strapped on this
    -- trailer). Returned to the caller so it can descend into THEIR own
    -- implements for nested separate-body cargo — bales on a bale spike,
    -- logs on a fork — which isn't in the strapped vehicle's physics mass.
    local strappedVehicles = {}
    local svSeen = {}
    local function noteStrappedVehicle(obj)
        if type(obj) == "table" and type(obj.getAttachedImplements) == "function"
           and not svSeen[obj] then
            svSeen[obj] = true
            strappedVehicles[#strappedVehicles + 1] = obj
        end
    end

    -- Walk belt candidates first (wood + belt-strapped non-wood)
    for id, _ in pairs(beltCandidates) do
        if wawi_isSplitShapeId(id) then
            local volL = wawi_getVolumeLiters(id)
            -- Source: spec_tensionBelts.objectsToJoint[id].objectMass (in
            -- tons) is the piece's original mass cached by GIANTS at belt-
            -- join time. But when belt-merged, GIANTS leaves a small
            -- residual (~10 kg) on the split-shape itself and transfers
            -- only (objectMass - residual) into the trailer's physics
            -- mass. To keep our Load matching the physics reality that
            -- every other in-game weight display sees, subtract the live
            -- residual from objectMass per piece. Confirmed: across a
            -- 9-log test, residual sum = 90 kg = HUD/physics gap exactly.
            local addKg
            local rec = jointByNodeId[id]
            if rec == nil and specTB ~= nil and type(specTB.objectsToJoint) == "table" then
                -- Direct lookup as a second chance (covers the rare case
                -- where the ID was added via strappedSplitShapes[] but
                -- indexed under a different key in objectsToJoint).
                rec = specTB.objectsToJoint[id]
            end
            if type(rec) == "table" and type(rec.objectMass) == "number" and rec.objectMass > 0 then
                local residualKg = wawi_getMassKg(id)  -- ~10 kg while belt-merged
                addKg = (rec.objectMass * 1000.0) - residualKg
                if addKg < 0 then addKg = 0 end
            else
                -- Fallback: vol*0.7 density estimate (~8% over for fresh
                -- softwood). Only hit when the joint record is missing
                -- objectMass for some reason.
                addKg = volL * 0.7
            end
            woodL      = woodL  + volL
            woodKg     = woodKg + addKg
            woodPieces = woodPieces + 1
        else
            if entityExists == nil or entityExists(id) then
                -- For non-wood strapped items (pallets / crates / vehicles),
                -- use the joint record's .object reference when available
                -- so multi-component tractors report their full mass, not
                -- just the single rigid body exposed by getMass.
                local jointRec = jointByNodeId[id]
                local nwKg = 0
                local resolved = nil
                if jointRec ~= nil then
                    nwKg = wawi_resolveStrappedObjectMassKg(id, jointRec)
                    if type(jointRec.object) == "table" then resolved = jointRec.object end
                else
                    nwKg = wawi_getMassKg(id)
                end
                if resolved == nil then resolved = wawi_findVehicleByNode(id) end
                noteStrappedVehicle(resolved)
                beltNonWoodKg = beltNonWoodKg + nwKg
            end
        end
    end

    -- Walk DMA-only candidates (separate-body cargo by default — spike
    -- bales, forklift pallets). The main loop will reclassify into the
    -- merged-cargo bucket when it detects the autoload-trailer case via
    -- (rawPhys - empty - fuel - wood) > 50 with hasBeltObjects or hasDMAObjects.
    for id, _ in pairs(dmaCandidates) do
        if entityExists == nil or entityExists(id) then
            local nwKg = 0
            local obj = objectByNodeId[id]
            if obj ~= nil then
                local vm = wawi_getVehiclePhysicsMassKg(obj)
                if vm > 0 then nwKg = vm end
                noteStrappedVehicle(obj)
            end
            if nwKg <= 0 then
                nwKg = wawi_getMassKg(id)
            end
            dmaNonWoodKg = dmaNonWoodKg + nwKg
        end
    end

    return woodL, woodKg, woodPieces, beltNonWoodKg, dmaNonWoodKg,
           hasBeltObjects, hasDMAObjects, strappedVehicles
end

-- Returns true if a vehicle has any cargo-capture mechanism worth walking
-- (tension belts or a dynamic-mount attacher). Used by the update loop to
-- gate the belt-spec walker for the vehicle chain.
local function wawi_hasTensionBelts(v)
    if v == nil then return false end
    if v.spec_tensionBelts        ~= nil then return true end
    if v.spec_dynamicMountAttacher ~= nil then return true end
    return false
end

-- ─────────────────────────────────────────────
-- Livestock trailer detection
-- ─────────────────────────────────────────────
-- Detect a livestock-carrying trailer universally — any vehicle whose
-- typeName OR any spec key contains "livestock" or "animal". FS25's
-- typeManager registers Wilson Silverstar etc. as typeName="livestock-
-- Trailer", but the actual spec class name varies (spec_livestockTrailer,
-- spec_animalLoadingTrailer, etc.). Mods may use either, so we accept
-- both and fall back to typeName.
local function wawi_isLivestockTrailer(v)
    if v == nil then return false end
    if type(v.typeName) == "string" then
        local lt = string.lower(v.typeName)
        if string.find(lt, "livestock", 1, true) ~= nil
        or string.find(lt, "animal",    1, true) ~= nil then
            return true
        end
    end
    for k, val in pairs(v) do
        if type(k) == "string" and string.sub(k, 1, 5) == "spec_" and val ~= nil then
            local lk = string.lower(k)
            if string.find(lk, "livestock", 1, true) ~= nil
            or string.find(lk, "animal",    1, true) ~= nil then
                return true
            end
        end
    end
    return false
end

-- Live-animal mass for livestock trailers — universal physics-delta
-- approach. FS25 livestock trailers report hasFillVolume=false (the
-- per-animal data isn't surfaced via getFillUnits the way ordinary
-- cargo is), but the animal mass IS merged into the trailer's rigid
-- body. So `rawPhysicsKg - emptyMass` gives the exact animal cargo
-- mass with no per-fill-type tuning needed. Works for ANY animal age
-- (piglet → adult pig, calf → cow, etc.) and any mod-added livestock
-- type, because GIANTS' physics already accounts for per-animal mass
-- via the configured fill type's massPerLiter when an animal is loaded.
--
-- Caller MUST gate on `not wawi_hasFillVolume(v)` so we don't conflict
-- with the main fill block (which already does rawPhys-empty-wood-fuel
-- for any vehicle whose cargo IS exposed via fill units). The gate
-- above this body is defensive — keeps the function safe to call from
-- the update loop without checking each callsite.
local function wawi_getLivestockMassKg(v)
    if not wawi_isLivestockTrailer(v) then return 0 end
    if wawi_hasFillVolume(v) then return 0 end  -- handled by fill block
    local rawPhysKg = wawi_getVehiclePhysicsMassKg(v)
    local emptyKg   = wawi_getEmptyMassKg(v)
    if rawPhysKg <= 0 or emptyKg == nil then return 0 end
    local delta = rawPhysKg - emptyKg
    if delta <= 0 then return 0 end
    return delta
end

-- ─────────────────────────────────────────────
-- Equipment-held wood (winch rope + harvester head)
-- ─────────────────────────────────────────────
-- Wood attached to a forestry winch's rope or held by a tree-harvester head
-- is a SEPARATE rigid body from the vehicle, so its mass is not in the
-- vehicle's getMass. We surface it here so it contributes to the HUD "Load".
-- Field names in FS25's built-in specs aren't documented externally so we
-- probe a set of likely candidates defensively; anything that isn't a valid
-- split shape is ignored.
local function wawi_accumulateSplitShape(nodeId, acc)
    if type(nodeId) ~= "number" or nodeId == 0 then return end
    if not wawi_isSplitShapeId(nodeId) then return end
    if acc.seen[nodeId] then return end
    acc.seen[nodeId] = true
    local volL   = wawi_getVolumeLiters(nodeId)
    local massKg = wawi_getMassKg(nodeId)
    -- Prefer game physics mass when it's nonzero (matches what the scale
    -- would "feel"); fall back to volume * 0.7 as our existing wood estimate.
    local addKg  = massKg > 0 and massKg or (volL * 0.7)
    acc.kg     = acc.kg     + addKg
    acc.L      = acc.L      + volL
    acc.pieces = acc.pieces + 1
end

local function wawi_probeTableForShapeIds(t, acc)
    if type(t) ~= "table" then return end
    -- Possible field names that might hold a split-shape node ID on an
    -- attached-tree record. List is defensive — different mods/specs use
    -- different names. Any numeric field whose value is a valid split
    -- shape ID will be accumulated; others are ignored silently.
    local idFields = {
        "nodeId", "shapeId", "splitShape", "node", "tree",
        "shape", "treeShape", "rootSplitShape", "rootShape",
        "attachedNode", "attachedShape", "attachedSplitShape",
        "id", "treeId",
    }
    for _, v in pairs(t) do
        if type(v) == "number" then
            wawi_accumulateSplitShape(v, acc)
        elseif type(v) == "table" then
            for _, f in ipairs(idFields) do
                local val = v[f]
                if type(val) == "number" then
                    wawi_accumulateSplitShape(val, acc)
                end
            end
        end
    end
end

-- Forestry winch — fish attached wood out of whatever rope/attach fields the
-- spec exposes. The Tajfun eGV 65 debug dump (2026-04-17) revealed the real
-- layout used by FS25's built-in winch (spec_winch): a PLURAL `ropes` array,
-- plus `splitShapesToAttach` and `treeRaycast` sub-tables. The older
-- singular `spec.rope` guess is kept as a defensive fallback for modded
-- winches that use it.
local function wawi_probeWinchWood(v, acc)
    if v == nil then return end
    local spec = v.spec_forestryWinch or v.spec_winch or v.spec_tractionWinch
    if spec == nil then return end

    local scalarFields = {
        "attachedShape", "attachedSplitShape", "currentShape",
        "currentSplitShape", "attachedNode", "shape", "tree",
        "nodeId", "splitShape",
    }
    local nestedTableFields = {
        "attachments", "attachedShapes", "attachedTrees", "shapes",
        "trees", "splitShapes", "splitShapesToAttach",
    }

    local function probeRope(rope)
        if type(rope) ~= "table" then return end
        for _, f in ipairs(scalarFields) do
            wawi_accumulateSplitShape(rope[f], acc)
        end
        for _, f in ipairs(nestedTableFields) do
            wawi_probeTableForShapeIds(rope[f], acc)
        end
    end

    for _, f in ipairs(scalarFields) do
        wawi_accumulateSplitShape(spec[f], acc)
    end

    -- Plural array (confirmed layout for stock spec_winch)
    if type(spec.ropes) == "table" then
        for _, rope in pairs(spec.ropes) do
            probeRope(rope)
        end
    end
    -- Singular fallback (older/modded winches)
    probeRope(spec.rope)

    -- Spec-level nested tables
    for _, f in ipairs(nestedTableFields) do
        wawi_probeTableForShapeIds(spec[f], acc)
    end

    -- treeRaycast: currently-aimed-at tree. May hold a captured split shape
    -- while the rope is pulling it in.
    if type(spec.treeRaycast) == "table" then
        for _, f in ipairs(scalarFields) do
            wawi_accumulateSplitShape(spec.treeRaycast[f], acc)
        end
    end
end

-- Tree harvester head — grabbed tree while the head is closed around a trunk.
-- Likely spec_woodHarvester; alt names probed too.
local function wawi_probeHarvesterWood(v, acc)
    if v == nil then return end
    local spec = v.spec_woodHarvester or v.spec_cutter or v.spec_treeSaw
    if spec == nil then return end

    local scalarFields = {
        "curSplitShape", "currentSplitShape", "grabbedSplitShape",
        "treeShape", "currentTree", "grabbedTree", "cutShape",
        "currentCutShape", "attachedSplitShape", "curTreeShape",
    }
    for _, f in ipairs(scalarFields) do
        wawi_accumulateSplitShape(spec[f], acc)
    end

    -- Sometimes the head exposes a saw/grabber sub-table
    for _, subName in ipairs({"treeSaw", "grabber", "head"}) do
        local sub = spec[subName]
        if type(sub) == "table" then
            for _, f in ipairs(scalarFields) do
                wawi_accumulateSplitShape(sub[f], acc)
            end
        end
    end

    wawi_probeTableForShapeIds(spec.attachedTrees,  acc)
    wawi_probeTableForShapeIds(spec.grabbedTrees,   acc)
    wawi_probeTableForShapeIds(spec.grabbedShapes,  acc)
end

-- Log grab / log fork — wood-clamping implements that pick up split shapes
-- via spec_logGrab. Field layout varies, so we probe scalar shape-id fields
-- defensively, then sweep any nested tables for shape ids. Hit by the
-- Albutt Log Fork (typeName=logGrab) and similar implements that don't have
-- spec_dynamicMountAttacher (so the strapped-cargo walker misses them).
local function wawi_probeLogGrabWood(v, acc)
    if v == nil then return end
    local spec = v.spec_logGrab or v.spec_grab or v.spec_logHook
    if spec == nil then return end

    -- Canonical FS25 layout (verified 2026-04-27 via debug dump on the
    -- Albutt Log Fork): the held wood ids live as KEYS of the per-grab
    -- `dynamicMountedShapes` table. Each value is a small struct with
    -- the joint metadata: { jointIndex, jointTransform }.
    --
    --   spec_logGrab = {
    --     grabs = {
    --       [1] = {                                    -- one entry per
    --         dynamicMountedShapes = {                 -- grab/clamp set
    --           [<splitShapeId>] = { jointIndex, jointTransform },
    --           ...                                    -- one entry per
    --         },                                       -- held log
    --         ... 22 other config/state fields ...
    --       },
    --     },
    --   }
    --
    -- This is the AUTHORITATIVE list of currently-grabbed wood — populated
    -- on grab, cleared on release. Stable across ticks (no flicker), and
    -- automatically handles multi-piece pickup because the table holds
    -- one entry per held log.
    if type(spec.grabs) ~= "table" then return end
    for _, grab in pairs(spec.grabs) do
        if type(grab) == "table" and type(grab.dynamicMountedShapes) == "table" then
            for shapeId, _ in pairs(grab.dynamicMountedShapes) do
                if type(shapeId) == "number" then
                    wawi_accumulateSplitShape(shapeId, acc)
                end
            end
        end
    end
end

local function wawi_newEquipAcc()
    return { kg = 0, L = 0, pieces = 0, seen = {} }
end

-- ─────────────────────────────────────────────
-- Background overlay
-- ─────────────────────────────────────────────
local function wawi_ensureBgOverlay()
    if WoodAndWeightInfo._bgOverlay ~= nil then return end
    if createImageOverlay == nil then WoodAndWeightInfo._bgOverlay = false; return end
    local ok, ov = pcall(createImageOverlay, "data/shared/white_diffuse.png")
    if ok and ov ~= nil and ov ~= 0 then
        WoodAndWeightInfo._bgOverlay = ov
    else
        WoodAndWeightInfo._bgOverlay = false
    end
end

local function wawi_drawBg(x, y, w, h)
    local ov = WoodAndWeightInfo._bgOverlay
    if ov == nil or ov == false then return end
    if setOverlayColor == nil or renderOverlay == nil then return end
    setOverlayColor(ov, 0.06, 0.06, 0.06, 0.75)
    renderOverlay(ov, x, y, w, h)
end

-- ─────────────────────────────────────────────
-- Safe text rendering wrappers
-- ─────────────────────────────────────────────
local function wawi_safeSetAlign(align)
    if setTextAlignment ~= nil then setTextAlignment(align) end
end

local function wawi_safeSetColor(r, g, b, a)
    if setTextColor ~= nil then setTextColor(r, g, b, a) end
end

local function wawi_safeSetBold(bold)
    if setTextBold ~= nil then setTextBold(bold) end
end

local function wawi_safeRender(x, y, size, text)
    if renderText ~= nil then renderText(x, y, size, text) end
end

-- ─────────────────────────────────────────────
-- Cursor visibility + camera-rotation lockout
-- (inlined Click-to-Switch style)
-- ─────────────────────────────────────────────
local function wawi_setCursorShown(shown)
    if g_inputBinding == nil then return end
    pcall(function()
        if g_inputBinding.setShowMouseCursor ~= nil then
            g_inputBinding:setShowMouseCursor(shown and true or false)
        end
    end)
end

-- Lock/unlock camera rotation on the active vehicle so the world doesn't
-- spin while the player is moving the HUD with the mouse. Mirrors the
-- ClickToSwitch.actionEventToggleMouse pattern.
local function wawi_lockCameraRotation()
    local v = wawi_getActiveVehicle and wawi_getActiveVehicle() or nil
    if v == nil or v.spec_enterable == nil or v.spec_enterable.cameras == nil then return end
    WoodAndWeightInfo._camLockVehicle = v
    WoodAndWeightInfo._camLockBackup  = {}
    for camIndex, camera in pairs(v.spec_enterable.cameras) do
        if camera ~= nil and camera.isRotatable then
            WoodAndWeightInfo._camLockBackup[camIndex] = true
            camera.isRotatable = false
        end
    end
end

local function wawi_unlockCameraRotation()
    local v = WoodAndWeightInfo._camLockVehicle
    local backup = WoodAndWeightInfo._camLockBackup
    WoodAndWeightInfo._camLockVehicle = nil
    WoodAndWeightInfo._camLockBackup  = nil
    if v == nil or backup == nil then return end
    if v.spec_enterable == nil or v.spec_enterable.cameras == nil then return end
    for camIndex, _ in pairs(backup) do
        local cam = v.spec_enterable.cameras[camIndex]
        if cam ~= nil then cam.isRotatable = true end
    end
end

local function wawi_enterRepositionMode()
    WoodAndWeightInfo._repositionMode = true
    -- Seed position from engine's last cursor to avoid an initial (0,0) snap.
    if g_inputBinding ~= nil then
        local mx = g_inputBinding.mousePosXLast
        local my = g_inputBinding.mousePosYLast
        if type(mx) == "number" then WoodAndWeightInfo._mouseX = mx end
        if type(my) == "number" then WoodAndWeightInfo._mouseY = my end
    end
    wawi_setCursorShown(true)
    wawi_lockCameraRotation()
    wawi_showNotification("WAWI: Move HUD with mouse, left-click to save")
end

local function wawi_finalizeRepositionMode()
    -- The ghost draw stored the wood-box anchor derived from the cursor
    -- (which pins the Total Weight box); save that so placed mode matches.
    WoodAndWeightInfo._savedX    = WoodAndWeightInfo._lastAx or WoodAndWeightInfo._mouseX
    WoodAndWeightInfo._savedY    = WoodAndWeightInfo._lastAy or WoodAndWeightInfo._mouseY
    WoodAndWeightInfo._posCustom = true
    WoodAndWeightInfo._repositionMode = false
    wawi_unlockCameraRotation()
    wawi_setCursorShown(false)
    wawi_saveSettings()
    wawi_showNotification("WAWI: Position saved")
end

-- ─────────────────────────────────────────────
-- Action callbacks
-- ─────────────────────────────────────────────
function WoodAndWeightInfo:onToggleHUD(_, _)
    WoodAndWeightInfo._enabled = not WoodAndWeightInfo._enabled
end

function WoodAndWeightInfo:onReposition(_, _)
    local now = g_time or 0
    if now - (WoodAndWeightInfo._lastRepositionMs or -100000) < 220 then return end
    WoodAndWeightInfo._lastRepositionMs = now

    if WoodAndWeightInfo._repositionMode then
        wawi_finalizeRepositionMode()
    else
        wawi_enterRepositionMode()
    end
end

-- ─────────────────────────────────────────────
-- Mouse event for HUD reposition
-- FS25 mouseEvent coords match render space (bottom-up 0..1).
function WoodAndWeightInfo:mouseEvent(posX, posY, isDown, isUp, button)
    if not WoodAndWeightInfo._repositionMode then return end
    WoodAndWeightInfo._mouseX = posX
    WoodAndWeightInfo._mouseY = posY
    local LMB = (Input ~= nil and Input.MOUSE_BUTTON_LEFT) or 1
    if isDown and button == LMB then
        wawi_finalizeRepositionMode()
    end
end

-- ─────────────────────────────────────────────
-- loadMap
-- ─────────────────────────────────────────────
function WoodAndWeightInfo:loadMap()
    wawi_buildSplitClassIdCache()
    wawi_loadSettings()

    if WoodAndWeightInfo.MOD_DIR == nil or WoodAndWeightInfo.MOD_DIR == "" then
        WoodAndWeightInfo.MOD_DIR = g_currentModDirectory or ""
    end
    -- HUD scale (1.0 = original size).
    if WoodAndWeightInfo._hudScale == nil then WoodAndWeightInfo._hudScale = 0.533 end
    if WoodAndWeightInfo._horizontal == nil then WoodAndWeightInfo._horizontal = false end

    self.s = {
        next        = 0,
        woodL       = 0,
        woodPieces  = 0,
        loadKg      = 0,
        grossKg     = 0,
        showWood    = false,
        inVehicle   = false,
        lastErr     = "",
    }
    WoodAndWeightInfo._enabled          = true
    WoodAndWeightInfo._lastVehicle      = nil
    WoodAndWeightInfo._dispLoadKg       = nil
    WoodAndWeightInfo._dispGrossKg      = nil
end

-- ─────────────────────────────────────────────
-- Load display smoothing
-- ─────────────────────────────────────────────
-- The Load is now weighed straight from the fill units (liters * physics
-- density, see the fill block in update()), so it is already exact and
-- identical in every vehicle, with no fuel-burn desync to fight. This is a
-- light cosmetic damp only:
--   * |delta| >= SNAP   -> a real load/unload: snap immediately
--   * |delta| <  EXACT  -> essentially there: snap to the EXACT value, so the
--                          number always lands on the true weight (no residual,
--                          no exit/re-enter, matches across vehicles)
--   * in between         -> ease in over a couple of frames so a big change
--                          slides rather than teleports
-- The SAME damp is applied to Total (Gross) as well, so Load, Total and Tons
-- (Tons is derived from Total) all move in lockstep. It is light enough that
-- Total still effectively tracks realtime -- fuel changes snap through -- and
-- the underlying Load/Gross math is untouched.
local WAWI_LOAD_SNAP_KG  = 50.0  -- |delta| >= this: real load/unload -> snap
local WAWI_LOAD_EXACT_KG = 3.0   -- |delta| <  this: close enough -> snap to EXACT
local WAWI_LOAD_EASE     = 0.35  -- mid-range: ease toward truth (smooth but quick)

-- `field` names the per-value display state on WoodAndWeightInfo, so the same
-- damp drives Load (_dispLoadKg) and Total (_dispGrossKg) identically.
local function wawi_damp(field, targetKg, activeVehicle)
    local cur = WoodAndWeightInfo[field]
    -- Snap on first sample or whenever the controlled vehicle changes,
    -- so we never ease from a previous vehicle's value into a new one.
    if cur == nil or activeVehicle ~= WoodAndWeightInfo._lastVehicle then
        WoodAndWeightInfo[field] = targetKg
        return targetKg
    end
    local diff  = targetKg - cur
    local adiff = (diff < 0) and -diff or diff
    if adiff >= WAWI_LOAD_SNAP_KG or adiff < WAWI_LOAD_EXACT_KG then
        WoodAndWeightInfo[field] = targetKg                     -- snap: big change, or already exact
    else
        WoodAndWeightInfo[field] = cur + diff * WAWI_LOAD_EASE   -- ease mid-range
    end
    return WoodAndWeightInfo[field]
end

-- ─────────────────────────────────────────────
-- update  (throttled; runs every UPDATE_MS ms)
-- ─────────────────────────────────────────────
function WoodAndWeightInfo:update(dt)
    if g_currentMission == nil or self.s == nil then return end

    self.s.next = (self.s.next or 0) - dt

    local ok, err = pcall(function()
        if self.s.next > 0 then return end
        self.s.next = WoodAndWeightInfo.UPDATE_MS

        local active = wawi_getActiveVehicle()

        if active == nil then
            self.s.inVehicle  = false
            self.s.showWood   = false
            self.s.woodL      = 0
            self.s.woodPieces = 0
            self.s.loadKg     = 0
            self.s.grossKg    = 0
            self.s.lastErr    = ""
            WoodAndWeightInfo._lastVehicle = nil
            WoodAndWeightInfo._dispLoadKg  = nil
            WoodAndWeightInfo._dispGrossKg = nil
            return
        end

        self.s.inVehicle = true

        local top = wawi_getTopVehicle(active) or active
        local vehicleMassKg = 0
        local fillKg        = 0
        local strappedObjKg = 0  -- SEPARATE rigid bodies (outside rawPhys)
        local mergedCargoKg = 0  -- cargo merged INTO rawPhys; surfaces in
                                 -- Load only (NOT added to Gross again)
        local woodL         = 0
        local woodKg        = 0
        local woodPieces    = 0
        local chainHasBelts = false
        local chainHasFill  = false
        local equipAcc      = wawi_newEquipAcc()
        local chainHasEquip = false

        wawi_iterateAttached(top, function(v)
            if v == nil then return end

            -- Always use GIANTS' reported physics mass for this vehicle.
            -- It already includes: empty chassis + current fill + any wood
            -- merged via belt joints. It does NOT include separate rigid
            -- bodies (strapped non-wood, winch/harvester-held wood).
            local rawPhysicsKg = wawi_getVehiclePhysicsMassKg(v)
            local emptyKg      = wawi_getEmptyMassKg(v)

            -- Strapped cargo for THIS vehicle (one call; values reused below)
            local thisVWoodL, thisVWoodKg, thisVWoodPieces = 0, 0, 0
            local thisVBeltNonWoodKg, thisVDmaNonWoodKg     = 0, 0
            local hasBeltObjects                             = false
            local hasDMAObjects                              = false
            local thisVStrappedVehicles                      = nil
            if wawi_hasTensionBelts(v) then
                thisVWoodL, thisVWoodKg, thisVWoodPieces,
                thisVBeltNonWoodKg, thisVDmaNonWoodKg,
                hasBeltObjects, hasDMAObjects, thisVStrappedVehicles =
                    wawi_collectStrappedFromBeltSpec(v)
            end
            -- Default: belt/DMA cargo is treated as separate body (spike-
            -- mounted bales, flatbed pallets) — getMass returns the full
            -- mass. The merged case (autoload trailer, mass merged INTO
            -- the trailer rigid body) reclassifies these into mergedCargo
            -- below using the physics delta as the true cargo mass.
            local thisVStrappedObjKg = thisVBeltNonWoodKg + thisVDmaNonWoodKg
            local thisVMergedCargoKg = 0

            -- Nested cargo carried BY a strapped vehicle. A tractor strapped
            -- on this trailer can itself hold separate-body cargo on its own
            -- implements — bales on a bale spike, logs on a fork. That cargo
            -- is NOT in the strapped vehicle's physics mass (already counted
            -- in thisVStrappedObjKg), and its implements aren't in the active
            -- chain, so the main per-vehicle probes never see it. Walk each
            -- strapped vehicle's own implement chain here and add only what
            -- it's CARRYING. One level deep (tractor-on-trailer); we ignore
            -- any deeper strapped vehicles to stay bounded.
            if type(thisVStrappedVehicles) == "table" then
                -- Shared across all strapped vehicles for this trailer: if the
                -- belts caught the tractor AND its loader/spike as separate
                -- bodies, every implement is still probed exactly once, so the
                -- bales it carries are never multi-counted.
                local seenImpl = {}
                for _, sv in ipairs(thisVStrappedVehicles) do
                    wawi_iterateAttached(sv, function(impl)
                        if impl == nil or seenImpl[impl] then return end
                        seenImpl[impl] = true
                        -- belt/DMA-held cargo (bale spike, pallet fork)
                        if wawi_hasTensionBelts(impl) then
                            local _, iwKg, _, ibNW, idNW =
                                wawi_collectStrappedFromBeltSpec(impl)
                            thisVStrappedObjKg = thisVStrappedObjKg
                                + (ibNW or 0) + (idNW or 0) + (iwKg or 0)
                        end
                        -- equipment-held wood (winch / harvester / log fork)
                        local preKg = equipAcc.kg
                        pcall(wawi_probeWinchWood,     impl, equipAcc)
                        pcall(wawi_probeHarvesterWood, impl, equipAcc)
                        pcall(wawi_probeLogGrabWood,   impl, equipAcc)
                        if equipAcc.kg > preKg then chainHasEquip = true end
                    end)
                end
            end

            -- Fill contribution to the Load row — zero-drift calculation.
            --
            --   * Empty mass comes from v:getDefaultMass() (universal
            --     Vehicle API; returns configured empty mass in tons).
            --     This gives us a PHYSICS-accurate baseline with no
            --     density-manager rounding.
            --
            --   * Total fill physics mass = rawPhysicsKg - emptyKg - woodKg.
            --     This is exact (GIANTS ground truth) with zero drift,
            --     because every piece is a truth value.
            --
            --   * Consumer-fuel mass is subtracted so only user-added
            --     cargo fills count in the Load. Physics density comes
            --     from g_fillTypeManager's massPerLiter record — the
            --     SAME record GIANTS' fillVolume physics uses — so any
            --     fill type registered by any map/mod is handled with
            --     zero per-type tuning.
            --
            -- Falls back to the density-calc path only if getDefaultMass
            -- is unavailable (should never happen on Vehicle subclasses).
            local vFillContribKg = 0
            local ghostPhysKg    = 0  -- physics mass to deduct from Gross
            if wawi_hasFillVolume(v) then
                chainHasFill = true
                local cargoLiters = wawi_getTotalCargoLiters(v)
                if cargoLiters > 0 then
                    -- Registered cargo: weigh it directly from the fill units
                    -- as liters * physics density (the SAME massPerLiter record
                    -- GIANTS' fillVolume physics uses), excluding engine fuel.
                    -- This is the true cargo weight AND identical in every
                    -- vehicle -- a load reads the same in a harvester tank as in
                    -- a trailer -- and never touches fuel, so there's no
                    -- fuel-burn desync to smooth or leave stuck (numbers match
                    -- across vehicles with no exit/re-enter needed).
                    vFillContribKg = wawi_getFillMassKg(v, true)
                elseif emptyKg ~= nil then
                    local allFillPhysicsKg      = rawPhysicsKg - emptyKg - thisVWoodKg
                    local consumerFuelPhysicsKg = wawi_getConsumerFuelPhysicsKg(v)
                    vFillContribKg = allFillPhysicsKg - consumerFuelPhysicsKg
                    if vFillContribKg < 0 then vFillContribKg = 0 end
                    -- Three-way classification when no cargo liters are
                    -- registered in fill units (cargoL == 0):
                    --
                    --   (1) Merged cargo — autoload trailer with a bale
                    --       mounted into its rigid body via tensionBelts
                    --       OR dynamicMountAttacher. GIANTS leaves a
                    --       residual on the bale (~10-100 kg per bale)
                    --       and transfers (mass - residual) into the
                    --       trailer's physics. Both halves are real:
                    --         * residual stays in thisVStrappedObjKg
                    --           (already populated via getMass on bale —
                    --           a separate rigid body outside rawPhys).
                    --         * physics delta (vFillContrib) goes into
                    --           mergedCargoKg — the part inside rawPhys.
                    --       Sum: residual + delta = true bale mass.
                    --       No ghost deduct: the cargo IS real, and rawPhys
                    --       already includes the delta — Gross stays correct.
                    --
                    --   (2) Phantom mass — autoload-sold-while-mounted,
                    --       OR a frontloader bracket double-counted on
                    --       the parent tractor (loader's own rawPhys
                    --       reports separately, but its mass is also
                    --       baked into the tractor's rawPhys when
                    --       attached). No mounted objects detected here.
                    --       Deduct from rawPhys so Gross drops to empty.
                    --
                    --   (3) Tiny noise (≤50 kg) — small GIANTS-internal
                    --       residue (e.g. 12-17 kg of threshing residue
                    --       on an emptied combine). Just clamp to 0.
                    if wawi_getTotalCargoLiters(v) <= 0 then
                        local hasMountedObjects = hasBeltObjects or hasDMAObjects
                        if hasMountedObjects and vFillContribKg > 50.0 then
                            -- (1) merged cargo: keep residual + add delta
                            thisVMergedCargoKg = thisVMergedCargoKg + vFillContribKg
                            vFillContribKg     = 0
                        elseif vFillContribKg > 50.0 then
                            -- (2) phantom or loader-bracket double-count
                            ghostPhysKg    = vFillContribKg
                            vFillContribKg = 0
                        else
                            -- (3) noise
                            vFillContribKg = 0
                        end
                    end
                else
                    -- Legacy density path (no getDefaultMass available).
                    vFillContribKg = wawi_getFillMassKg(v, v == top)
                end
            end

            -- Livestock trailer fallback. Animals merge into the trailer
            -- rigid body and aren't surfaced via fill units, so detect
            -- via typeName/spec match and use rawPhys-empty as the cargo
            -- mass. mergedCargoKg → Load only (already in rawPhys, so
            -- Gross stays correct via vehicleMassKg = rawPhys).
            if not wawi_hasFillVolume(v) and wawi_isLivestockTrailer(v) then
                if rawPhysicsKg > 0 and emptyKg ~= nil then
                    local delta = rawPhysicsKg - emptyKg
                    if delta > 0 then
                        thisVMergedCargoKg = thisVMergedCargoKg + delta
                    end
                end
            end

            if thisVWoodPieces > 0 or thisVStrappedObjKg > 0 or thisVMergedCargoKg > 0 then
                chainHasBelts = true
            end

            woodL         = woodL         + thisVWoodL
            woodKg        = woodKg        + thisVWoodKg
            woodPieces    = woodPieces    + thisVWoodPieces
            strappedObjKg = strappedObjKg + thisVStrappedObjKg
            mergedCargoKg = mergedCargoKg + thisVMergedCargoKg
            vehicleMassKg = vehicleMassKg + rawPhysicsKg - ghostPhysKg
            fillKg        = fillKg + vFillContribKg

            -- Equipment-held wood: forestry winch rope / tree harvester
            -- head / log fork (spec_logGrab) / generic chain-wide fallback
            -- for cranes & custom mod implements. Each piece is a separate
            -- rigid body not in rawPhys, so we sum getMass per held shape
            -- and add it to Load + Gross via equipAcc.kg.
            -- Targeted equipment probes ONLY. The chain-wide all-specs
            -- scan has been disabled in production: it was finding
            -- stale/cached shape references in unrelated specs and
            -- producing phantom wood detection (1 piece + L showing with
            -- empty fork). Re-enable only after the diagnostic scan in
            -- the dump path identifies the actual spec/field holding the
            -- held wood reference, so we can add a precise probe for it.
            local preKg = equipAcc.kg
            pcall(wawi_probeWinchWood,      v, equipAcc)
            pcall(wawi_probeHarvesterWood,  v, equipAcc)
            pcall(wawi_probeLogGrabWood,    v, equipAcc)
            if equipAcc.kg > preKg then chainHasEquip = true end
        end)

        -- Data sources in this update:
        --   * vehicleMassKg   = Σ (rawPhysicsKg − ghostPhysKg)
        --                       GIANTS truth minus phantoms / loader-bracket
        --                       double-counts. Already includes empty
        --                       vehicle + current fill + merged wood +
        --                       merged DMA cargo + livestock animals.
        --   * woodKg          = Σ objectsToJoint[id].objectMass * 1000
        --                       (merged strapped wood per jointRec)
        --   * strappedObjKg   = Σ separate-body cargo getMass
        --                       (belt-strapped pallets/vehicles, spike
        --                        bales, forklift pallets — outside rawPhys)
        --   * mergedCargoKg   = autoload-merged DMA bales + livestock
        --                       animals (mass IS in rawPhys; surfaces in
        --                       Load only — DON'T add to Gross or it
        --                       double-counts)
        --   * equipAcc.kg     = Σ getMass(id) for winch/harvester wood
        --                       (separate rigid bodies)
        --   * fillKg          = Σ (rawPhysicsKg - emptyKg - woodKg - fuel)
        --                       zero-drift: empty via v:getDefaultMass(),
        --                       fuel via fill-type manager physics density
        --                       (same record GIANTS uses for fillVolume mass).

        -- HUD Wood row: consolidated display of everything wood.
        local displayWoodL      = woodL      + equipAcc.L
        local displayWoodKg     = woodKg     + equipAcc.kg
        local displayWoodPieces = woodPieces + equipAcc.pieces

        -- HUD Load row: sum of user-added cargo across the chain.
        local loadKg = 0
        if chainHasBelts or chainHasFill or chainHasEquip then
            loadKg = woodKg + strappedObjKg + mergedCargoKg + equipAcc.kg + fillKg
        end

        -- Gross = physics truth for the chain, plus the separate rigid
        -- bodies that GIANTS' getMass doesn't include:
        --   vehicleMassKg already has empty + fill + merged wood +
        --                 merged-DMA-cargo + livestock animals
        --   strappedObjKg is strapped non-wood (separate bodies — not in rawPhys)
        --   equipAcc.kg   is winch/harvester-held wood (separate bodies)
        -- Do NOT add fillKg or mergedCargoKg here — both are already in
        -- vehicleMassKg via rawPhysicsKg, so re-adding would double-count.
        local grossKg = vehicleMassKg + strappedObjKg + equipAcc.kg

        -- Re-expose consolidated totals for the HUD rows
        woodL      = displayWoodL
        woodKg     = displayWoodKg
        woodPieces = displayWoodPieces

        self.s.showWood   = (woodPieces > 0 or woodL > 0)
        self.s.woodL      = woodL
        self.s.woodPieces = woodPieces
        self.s.loadKg     = wawi_damp("_dispLoadKg",  loadKg,  active)  -- damped for HUD display
        self.s.grossKg    = wawi_damp("_dispGrossKg", grossKg, active)  -- same damp: Total/Tons track Load
        self.s.lastErr    = ""
        WoodAndWeightInfo._lastVehicle = active
    end)

    if not ok then
        self.s.lastErr   = tostring(err)
        self.s.inVehicle = false
        self.s.showWood  = false
    end
end

-- ─────────────────────────────────────────────
-- draw
-- ─────────────────────────────────────────────
-- Layout constants
local WAWI_LINE_H  = 0.020
local WAWI_SIZE    = 0.017
local WAWI_PAD_X   = 0.004
local WAWI_PAD_TOP = 0.003
local WAWI_PAD_BOT = 0.006
local WAWI_BOX_GAP = 0.010  -- gap between reposition label box and HUD box
-- Max possible line count (all metric + wood rows) for reserved reposition size:
--   1. Weight (primary unit)
--   2. Weight (t)  -- only imperial, but reserve slot anyway
--   3. Load
--   4. Wood pieces
--   5. Wood L
local WAWI_MAX_LINES = 5

-- ─────────────────────────────────────────────
-- Textured LED HUD  (box overlays + 7-segment digit atlas)
-- Frames/icons/labels are sliced from the user's artwork; the numbers are
-- stamped one glyph at a time from a UV atlas so they stay fully live.
-- ─────────────────────────────────────────────
local WAWI_CLUSTER_W = 0.150     -- BASE wood-box width at scale 1.0 (multiplied by _hudScale)
local WAWI_SIZE_STEP = 1.10      -- size up/down keybind multiplier per press
local WAWI_SIZE_MIN  = 0.05
local WAWI_SIZE_MAX  = 2.00
local WAWI_MOCK_W    = 613       -- wood-box width in source px (scale reference)
local WAWI_ATLAS_N   = 12        -- atlas cells: 0-9, blank(ghost), dot
local WAWI_GLYPH_AR  = 120 / 200 -- glyph width/height in the atlas
local WAWI_UV_VFLIP  = false     -- flip if digits render upside down in-game

-- Box source sizes
local WAWI_WOOD_W, WAWI_WOOD_H = 616, 176
local WAWI_IMPW_W, WAWI_IMPW_H = 488, 524   -- imperial weight-stack texture
local WAWI_METW_W, WAWI_METW_H = 484, 348   -- metric weight-stack texture
local WAWI_WBOXH = 168                       -- individual weight-box height (tight)
-- Full-texture placements for VERTICAL layout (origin = wood-box top-left)
local WAWI_BOX_WOOD = {0,   0,   616, 176}
local WAWI_BOX_IMPW = {127, 175, 488, 524}
local WAWI_BOX_METW = {130, 175, 484, 348}
-- Individual weight-box y-bands within their stack texture (top,bottom px)
local WAWI_UVB_IMP_LOAD  = {0,   168}
local WAWI_UVB_IMP_TOTAL = {173, 341}
local WAWI_UVB_IMP_TONS  = {346, 514}
local WAWI_UVB_MET_LOAD  = {0,   168}
local WAWI_UVB_MET_TOTAL = {174, 342}
-- Digit windows relative to their OWN box's top-left {mx,my,mw,mh}
local WAWI_WIN_PCS   = {191, 89, 124, 56}
local WAWI_WIN_WOODL = {352, 89, 238, 57}
local WAWI_WIN_WT    = {133, 71, 252, 68}   -- weight box (load / total / tons)

local function wawi_ensureTextures()
    local t = WoodAndWeightInfo._tex
    if t == "fail" then return false end
    if t ~= nil then return true end
    if createImageOverlay == nil then WoodAndWeightInfo._tex = "fail"; return false end
    local dir = WoodAndWeightInfo.MOD_DIR or ""
    local function load(name)
        local ok, ov = pcall(createImageOverlay, dir .. "textures/" .. name)
        if ok and ov ~= nil and ov ~= 0 then return ov end
        return nil
    end
    local tex = {
        wood  = load("wood_box.dds"),
        imp   = load("imp_weights.dds"),
        met   = load("met_weights.dds"),
        atlas = load("seg_atlas_v2.dds"),
    }
    if tex.wood == nil or tex.imp == nil or tex.met == nil or tex.atlas == nil then
        WoodAndWeightInfo._tex = "fail"; return false
    end
    WoodAndWeightInfo._tex = tex
    return true
end

-- Draw one box texture. Source-px rect m={mx,my,mw,mh} mapped to screen from
-- anchor (ax,ay = wood-box top-left, y-up) using scale (sx,sy).
local function wawi_blit(ov, ax, ay, sx, sy, m)
    if ov == nil or renderOverlay == nil then return end
    if setOverlayUVs ~= nil then setOverlayUVs(ov, 0, 0, 0, 1, 1, 0, 1, 1) end  -- full/upright (reset)
    if setOverlayColor ~= nil then setOverlayColor(ov, 1, 1, 1, 1) end
    renderOverlay(ov, ax + m[1] * sx, ay - (m[2] + m[4]) * sy, m[3] * sx, m[4] * sy)
end

-- Blit a horizontal uv-band (uy0,uy1 = top/bottom fraction of the texture) into
-- a source-px rect; used to place individual stacked boxes side-by-side.
local function wawi_blitBand(ov, ax, ay, sx, sy, mx, my, mw, mh, uy0, uy1)
    if ov == nil or renderOverlay == nil then return end
    if setOverlayUVs ~= nil then
        setOverlayUVs(ov, 0, 1 - uy1, 0, 1 - uy0, 1, 1 - uy1, 1, 1 - uy0)
    end
    if setOverlayColor ~= nil then setOverlayColor(ov, 1, 1, 1, 1) end
    renderOverlay(ov, ax + mx * sx, ay - (my + mh) * sy, mw * sx, mh * sy)
end

-- Right-aligned integer string; spaces become ghost (unlit) glyphs.
local function wawi_intStr(value, ndigits)
    local n = math.floor((value or 0) + 0.5)
    if n < 0 then n = 0 end
    local s = tostring(n)
    if #s > ndigits then s = string.rep("9", ndigits) end
    while #s < ndigits do s = " " .. s end
    return s
end

-- Stamp a digit string into a source-px window using the atlas.
local function wawi_digits(atlas, ax, ay, sx, sy, win, str, sizeN)
    if atlas == nil or renderOverlay == nil then return end
    local wmx, wmy, wmw, wmh = win[1], win[2], win[3], win[4]
    local n = #str
    sizeN = sizeN or n
    local dh  = wmh
    local dw  = dh * WAWI_GLYPH_AR
    local gap = dw * 0.12
    -- Size digits so `sizeN` FULL-width digits fit the window width. Any field
    -- with the same window + sizeN then renders identical-size numbers,
    -- regardless of how many chars the value actually has (e.g. tons "025.2").
    local refTotal = sizeN * dw + (sizeN > 1 and (sizeN - 1) * gap or 0)
    if refTotal > wmw and refTotal > 0 then
        local sc = wmw / refTotal
        dw = dw * sc; dh = dh * sc; gap = gap * sc
    end
    -- Actual rendered width of this string (the decimal point is narrower).
    local total = 0
    for i = 1, n do
        local ch = string.sub(str, i, i)
        total = total + ((ch == ".") and dw * 0.42 or dw)
        if i < n then total = total + gap end
    end
    local mx = wmx + wmw - total
    local my = wmy + (wmh - dh) * 0.5
    local vB, vT = 0, 1
    if WAWI_UV_VFLIP then vB, vT = 1, 0 end
    for i = 1, n do
        local ch = string.sub(str, i, i)
        local gi
        if ch == "." then gi = 11
        elseif ch == " " then gi = 10
        else gi = tonumber(ch) or 10 end
        local cw = (ch == ".") and dw * 0.42 or dw
        local uL = gi / WAWI_ATLAS_N
        local uR = (gi + 1) / WAWI_ATLAS_N
        if setOverlayUVs ~= nil then
            setOverlayUVs(atlas, uL, vB, uL, vT, uR, vB, uR, vT)
        end
        if setOverlayColor ~= nil then setOverlayColor(atlas, 1, 1, 1, 1) end
        renderOverlay(atlas, ax + mx * sx, ay - (my + dh) * sy, cw * sx, dh * sy)
        mx = mx + cw + gap
    end
end

local wawi_totalCenter   -- forward declaration (defined below; used by draw)

-- ─────────────────────────────────────────────
-- draw
-- ─────────────────────────────────────────────
function WoodAndWeightInfo:draw()
    local ok, _ = pcall(function()
        if self.s == nil then return end
        local repos = WoodAndWeightInfo._repositionMode
        if not repos then
            if not WoodAndWeightInfo._enabled then return end
            if not self.s.inVehicle then return end
            if self.s.lastErr ~= nil and self.s.lastErr ~= "" then return end
        end
        if renderOverlay == nil or not wawi_ensureTextures() then return end
        local tex = WoodAndWeightInfo._tex

        local imperial = wawi_useImperial()
        local sw = (g_screenWidth  and g_screenWidth  > 0) and g_screenWidth  or 1920
        local sh = (g_screenHeight and g_screenHeight > 0) and g_screenHeight or 1080
        local horiz = WoodAndWeightInfo._horizontal == true
        local sx = (WAWI_CLUSTER_W * (WoodAndWeightInfo._hudScale or 0.533)) / WAWI_MOCK_W
        local sy = sx * (sw / sh)
        local clusterPx = horiz and (WAWI_WOOD_W + (imperial and (WAWI_IMPW_W * 3) or (WAWI_METW_W * 2))) or WAWI_MOCK_W

        -- Anchor = wood-box top-left. In reposition mode the cursor pins the
        -- TOTAL WEIGHT box center, so toggling orientation pivots on it (and it
        -- can't march off-screen). We back the wood-box anchor out of that, and
        -- stash it so the save on click stores the wood-box position.
        local ax, ay
        if repos then
            local rx, ry = wawi_totalCenter(horiz, imperial)
            ax = WoodAndWeightInfo._mouseX - rx * sx
            ay = WoodAndWeightInfo._mouseY + ry * sy
            WoodAndWeightInfo._lastAx = ax
            WoodAndWeightInfo._lastAy = ay
        else
            ax, ay = wawi_getDrawPos()
        end

        local grossKg = self.s.grossKg or 0
        local loadKg  = self.s.loadKg  or 0
        local pieces  = self.s.woodPieces or 0
        local woodL   = self.s.woodL or 0
        if repos then
            grossKg = 39999; loadKg = 39999; pieces = 888; woodL = 888888
        end

        local function digW(bxp, byp, win, str, sizeN)
            wawi_digits(tex.atlas, ax, ay, sx, sy, {bxp + win[1], byp + win[2], win[3], win[4]}, str, sizeN)
        end

        if horiz then
            -- Left-to-right: wood, load, total, tons(imperial). Weight boxes
            -- vertically centered against the (taller) wood box.
            local yb = (WAWI_WOOD_H - WAWI_WBOXH) * 0.5
            local x  = WAWI_WOOD_W
            if imperial then
                local bw, H = WAWI_IMPW_W, WAWI_IMPW_H
                wawi_blitBand(tex.imp, ax, ay, sx, sy, x,          yb, bw, WAWI_WBOXH, WAWI_UVB_IMP_LOAD[1]/H,  WAWI_UVB_IMP_LOAD[2]/H)
                digW(x,          yb, WAWI_WIN_WT, wawi_intStr(loadKg  * LB_PER_KG, 6))
                wawi_blitBand(tex.imp, ax, ay, sx, sy, x + bw,     yb, bw, WAWI_WBOXH, WAWI_UVB_IMP_TOTAL[1]/H, WAWI_UVB_IMP_TOTAL[2]/H)
                digW(x + bw,     yb, WAWI_WIN_WT, wawi_intStr(grossKg * LB_PER_KG, 6))
                wawi_blitBand(tex.imp, ax, ay, sx, sy, x + bw * 2, yb, bw, WAWI_WBOXH, WAWI_UVB_IMP_TONS[1]/H,  WAWI_UVB_IMP_TONS[2]/H)
                digW(x + bw * 2, yb, WAWI_WIN_WT, string.format("%05.1f", grossKg / KG_PER_SHORT_TON), 6)
            else
                local bw, H = WAWI_METW_W, WAWI_METW_H
                wawi_blitBand(tex.met, ax, ay, sx, sy, x,      yb, bw, WAWI_WBOXH, WAWI_UVB_MET_LOAD[1]/H,  WAWI_UVB_MET_LOAD[2]/H)
                digW(x,      yb, WAWI_WIN_WT, wawi_intStr(loadKg,  6))
                wawi_blitBand(tex.met, ax, ay, sx, sy, x + bw, yb, bw, WAWI_WBOXH, WAWI_UVB_MET_TOTAL[1]/H, WAWI_UVB_MET_TOTAL[2]/H)
                digW(x + bw, yb, WAWI_WIN_WT, wawi_intStr(grossKg, 6))
            end
            if repos or self.s.showWood then
                wawi_blit(tex.wood, ax, ay, sx, sy, WAWI_BOX_WOOD)
                digW(0, 0, WAWI_WIN_PCS,   wawi_intStr(pieces, 3))
                digW(0, 0, WAWI_WIN_WOODL, wawi_intStr(woodL, 6))
            end
        else
            local WX = imperial and 127 or 130
            if imperial then
                wawi_blit(tex.imp, ax, ay, sx, sy, WAWI_BOX_IMPW)
                digW(WX, 175 + WAWI_UVB_IMP_LOAD[1],  WAWI_WIN_WT, wawi_intStr(loadKg  * LB_PER_KG, 6))
                digW(WX, 175 + WAWI_UVB_IMP_TOTAL[1], WAWI_WIN_WT, wawi_intStr(grossKg * LB_PER_KG, 6))
                digW(WX, 175 + WAWI_UVB_IMP_TONS[1],  WAWI_WIN_WT, string.format("%05.1f", grossKg / KG_PER_SHORT_TON), 6)
            else
                wawi_blit(tex.met, ax, ay, sx, sy, WAWI_BOX_METW)
                digW(WX, 175 + WAWI_UVB_MET_LOAD[1],  WAWI_WIN_WT, wawi_intStr(loadKg,  6))
                digW(WX, 175 + WAWI_UVB_MET_TOTAL[1], WAWI_WIN_WT, wawi_intStr(grossKg, 6))
            end
            if repos or self.s.showWood then
                wawi_blit(tex.wood, ax, ay, sx, sy, WAWI_BOX_WOOD)
                digW(0, 0, WAWI_WIN_PCS,   wawi_intStr(pieces, 3))
                digW(0, 0, WAWI_WIN_WOODL, wawi_intStr(woodL, 6))
            end
        end

        if repos then
            wawi_ensureBgOverlay()
            local topLabel = "[REPOSITION - Left Click to Save]"
            local tw = (getTextWidth ~= nil and getTextWidth(WAWI_SIZE, topLabel)) or 0.18
            local bw = tw + WAWI_PAD_X * 2
            local bh = WAWI_LINE_H + WAWI_PAD_TOP + WAWI_PAD_BOT
            local bx = ax + (clusterPx * sx - bw) * 0.5
            local by = ay + WAWI_BOX_GAP
            wawi_drawBg(bx, by, bw, bh)
            wawi_safeSetAlign(1)
            wawi_safeSetColor(0.2, 0.6, 1.0, 1)
            wawi_safeRender(bx + bw * 0.5, by + (bh - WAWI_SIZE) * 0.5, WAWI_SIZE, topLabel)
            wawi_safeSetAlign(0)
        end
    end)
    if not ok then
        -- silently swallow draw errors to avoid log spam
    end
end

-- Cluster-relative source-px CENTER of the Total Weight box, per layout/unit.
-- Used to pivot the HUD around that box when the layout is toggled, so it
-- doesn't march off-screen when switching orientations.
function wawi_totalCenter(horiz, imperial)
    local bw = imperial and WAWI_IMPW_W or WAWI_METW_W
    if horiz then
        local x  = WAWI_WOOD_W + bw               -- 3rd box: wood, load, total
        local yb = (WAWI_WOOD_H - WAWI_WBOXH) * 0.5
        return x + bw * 0.5, yb + WAWI_WBOXH * 0.5
    end
    local WX  = imperial and 127 or 130
    local top = 175 + (imperial and WAWI_UVB_IMP_TOTAL[1] or WAWI_UVB_MET_TOTAL[1])
    return WX + bw * 0.5, top + WAWI_WBOXH * 0.5
end

addModEventListener(WoodAndWeightInfo)

-- ─────────────────────────────────────────────
-- PlayerInputComponent hook for rebindable controls
-- ─────────────────────────────────────────────
if PlayerInputComponent ~= nil and Utils ~= nil and Utils.appendedFunction ~= nil then
    function PlayerInputComponent:wawiToggleCallback(actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory)
        WoodAndWeightInfo._enabled = not WoodAndWeightInfo._enabled
    end

    function PlayerInputComponent:wawiRepositionCallback(actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory)
        WoodAndWeightInfo:onReposition(nil, 1.0)
    end

    function PlayerInputComponent:wawiSizeUpCallback(actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory)
        local s = (WoodAndWeightInfo._hudScale or 0.2) * WAWI_SIZE_STEP
        if s > WAWI_SIZE_MAX then s = WAWI_SIZE_MAX end
        WoodAndWeightInfo._hudScale = s
        wawi_saveSettings()
    end

    function PlayerInputComponent:wawiSizeDownCallback(actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory)
        local s = (WoodAndWeightInfo._hudScale or 0.2) / WAWI_SIZE_STEP
        if s < WAWI_SIZE_MIN then s = WAWI_SIZE_MIN end
        WoodAndWeightInfo._hudScale = s
        wawi_saveSettings()
    end

    function PlayerInputComponent:wawiLayoutCallback(actionName, inputValue, callbackState, isAnalog, isMouse, deviceCategory)
        if not WoodAndWeightInfo._repositionMode then
            -- Placed: re-anchor so the Total Weight box stays fixed on screen
            -- across the flip. (In reposition mode the cursor already pins it.)
            local imperial = wawi_useImperial()
            local ax, ay = wawi_getDrawPos()
            local sw = (g_screenWidth  and g_screenWidth  > 0) and g_screenWidth  or 1920
            local sh = (g_screenHeight and g_screenHeight > 0) and g_screenHeight or 1080
            local sx = (WAWI_CLUSTER_W * (WoodAndWeightInfo._hudScale or 0.533)) / WAWI_MOCK_W
            local sy = sx * (sw / sh)
            local ocx, ocy = wawi_totalCenter(WoodAndWeightInfo._horizontal == true, imperial)
            WoodAndWeightInfo._horizontal = not WoodAndWeightInfo._horizontal
            local ncx, ncy = wawi_totalCenter(WoodAndWeightInfo._horizontal == true, imperial)
            WoodAndWeightInfo._savedX    = ax + (ocx - ncx) * sx
            WoodAndWeightInfo._savedY    = ay + (ncy - ocy) * sy
            WoodAndWeightInfo._posCustom = true
        else
            WoodAndWeightInfo._horizontal = not WoodAndWeightInfo._horizontal
        end
        wawi_saveSettings()
        wawi_showNotification(WoodAndWeightInfo._horizontal and "WAWI: Horizontal layout" or "WAWI: Vertical layout")
    end

    PlayerInputComponent.registerGlobalPlayerActionEvents = Utils.appendedFunction(
        PlayerInputComponent.registerGlobalPlayerActionEvents,
        function(self, controlling)
            local actions = {
                {name = "WAWI_TOGGLE",     cb = self.wawiToggleCallback,     up = false, down = true},
                {name = "WAWI_REPOSITION", cb = self.wawiRepositionCallback, up = false, down = true},
                {name = "WAWI_SIZE_UP",    cb = self.wawiSizeUpCallback,     up = false, down = true},
                {name = "WAWI_SIZE_DOWN",  cb = self.wawiSizeDownCallback,   up = false, down = true},
                {name = "WAWI_LAYOUT",     cb = self.wawiLayoutCallback,     up = false, down = true},
            }
            for _, a in ipairs(actions) do
                local inputAction = InputAction ~= nil and InputAction[a.name] or a.name
                local _, eventId = g_inputBinding:registerActionEvent(
                    inputAction, self, a.cb,
                    a.up, a.down, false, true, nil, true
                )
                if eventId ~= nil then
                    pcall(function() g_inputBinding:setActionEventTextPriority(eventId, GS_PRIO_VERY_LOW) end)
                    pcall(function() g_inputBinding:setActionEventTextVisibility(eventId, false) end)
                end
            end
        end
    )

    WoodAndWeightInfo._actionEventHooked = true
end
